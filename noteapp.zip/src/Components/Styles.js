import React from 'react';
import './style.css'


function Styles() {
    return (
        <div>
           <h1 className = 'primary'> Saikiran</h1>
        </div>
    )
}

export default Styles;
