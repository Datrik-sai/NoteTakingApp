import React from 'react'

console.log(React.version);

