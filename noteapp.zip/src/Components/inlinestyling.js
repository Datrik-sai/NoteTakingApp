import React from 'react'

const inline = {
    fontSize: '50px',
    color: 'blue'
}
function InlineStyling() {
    return (
        <div style = {inline}>
            welcome kiran
        </div>
    )
}
export default InlineStyling;