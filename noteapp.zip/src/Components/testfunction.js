import React from 'react'

const Greet = (props) =>{
    return(
        <div> {props.name} :My world my love</div>
    )
}

export default Greet;

